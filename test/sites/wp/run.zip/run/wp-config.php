<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, and ABSPATH. You can find more information by visiting
 * {@link http://codex.wordpress.org/Editing_wp-config.php Editing wp-config.php}
 * Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wp');

/** MySQL database username */
define('DB_USER', 'test');

/** MySQL database password */
define('DB_PASSWORD', 'dummy');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'I*#1UUF^xi)6EdM!SW|<&%9nd6m%i[|B+)H~+]mJ,{_R4G9|0J8>!E?w)Y:I~xPe');
define('SECURE_AUTH_KEY',  '_ipU1xhOzvl$@C6+p[iLH,%e0+[Rxt-)l|*;+*cwtiE`I_-aQi`tr {idV!6|8&s');
define('LOGGED_IN_KEY',    ';|$s@BzGBY/(o:G|:mHO@rVec|7=L!a<@6yx$9utk=#)y2hegnJDjYn=|nC~{+T+');
define('NONCE_KEY',        'HX>LOgbsQJH$diRJxel|W3ms<`:Hr+1AB#n=`~/E.4i`_SB;H;8nlb|~+[t1RGOA');
define('AUTH_SALT',        ':!PGC?xMY02RWWEY<4Gw8Y]BRlWTzew}s<**x|]nb_ybpNch!hF ;yGT+z>,>RNl');
define('SECURE_AUTH_SALT', '/btzA6/^A6ih|u:+X{_%!@2gC.o%s5nvfywn]x*zNdR|Y4pSD2$0(PC`U-e2[[P1');
define('LOGGED_IN_SALT',   'Ir%%RJ0E+?k+pHDT{q2TdFs0PQLXy8S#IppSN][71[&T9l!>G-R*-$Lo.F`Cg2|`');
define('NONCE_SALT',       'ds$L?gujQ=nI[LJMy$y|VBz/]Js4/[!UVsM7exIg_0}1,-v8q)6c =|`)^vg#H?K');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
